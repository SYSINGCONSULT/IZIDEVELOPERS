
import { BookOpen, Box, GitBranch, List, RefreshCw } from "lucide-react";
import { cn } from "@/lib/utils";

interface SidebarProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
}

const Sidebar = ({ activeSection, onSectionChange }: SidebarProps) => {
  const sections = [
    { id: "introduccion", name: "Introducción", icon: BookOpen },
    { id: "requisitos", name: "Requisitos", icon: List },
    { id: "integracion", name: "Integración", icon: Box },
    { id: "flujo-pedidos", name: "Flujo de pedidos", icon: GitBranch },
    { id: "actualizaciones", name: "Actualizaciones", icon: RefreshCw },
  ];

  return (
    <aside className="w-64 h-screen bg-[#1A1F2C] fixed left-0 top-0 p-4">
      <div className="flex items-center gap-3 mb-8 px-4">
        <img 
          src="/lovable-uploads/ab2b5cf5-c0ff-4d0d-8696-0f7436f14a4a.png" 
          alt="Izipay Logo" 
          className="w-8 h-8 object-contain"
        />
        <h1 className="font-bold text-lg text-[#fdfeff]">Plugin Vtex</h1>
      </div>
      <nav className="space-y-2">
        {sections.map((section) => {
          const Icon = section.icon;
          return (
            <button
              key={section.id}
              onClick={() => onSectionChange(section.id)}
              className={cn(
                "nav-item w-full text-[#fdfeff]",
                activeSection === section.id && "active"
              )}
            >
              <Icon className="w-5 h-5" />
              {section.name}
            </button>
          );
        })}
      </nav>
    </aside>
  );
};

export default Sidebar;
