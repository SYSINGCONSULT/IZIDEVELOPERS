import { cn } from "@/lib/utils";

interface CodeBlockProps {
  code: string;
  language?: string;
  className?: string;
}

const CodeBlock = ({ code, language = "json", className }: CodeBlockProps) => {
  return (
    <pre className={cn("language-" + language, "bg-[#1A1F2C] text-[#D6BCFA] font-mono text-sm", className)}>
      <code>{code}</code>
    </pre>
  );
};

export default CodeBlock;