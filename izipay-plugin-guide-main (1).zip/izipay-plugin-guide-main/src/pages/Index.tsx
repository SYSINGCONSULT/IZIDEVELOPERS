
import { useState } from "react";
import Sidebar from "@/components/Sidebar";
import CodeBlock from "@/components/CodeBlock";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { Home, ArrowRight, CreditCard, QrCode } from "lucide-react";

const Index = () => {
  const [activeSection, setActiveSection] = useState("introduccion");

  const sampleCode = `{
  "name": "izipay-vtex-plugin",
  "version": "1.0.0",
  "dependencies": {
    "vtex": "^2.0.0"
  }
}`;

  return (
    <div className="flex min-h-screen bg-[#fdfeff]">
      <Sidebar activeSection={activeSection} onSectionChange={setActiveSection} />
      
      <main className="flex-1 ml-64 p-8">
        <Breadcrumb className="mb-6">
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink href="/">
                <Home className="h-4 w-4" />
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbPage>{activeSection.charAt(0).toUpperCase() + activeSection.slice(1)}</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>

        <section id="introduccion" className={activeSection === "introduccion" ? "block" : "hidden"}>
          {/* Primera sección: Bienvenida e Imagen */}
          <div className="bg-gradient-to-r from-[#ec3237] to-[#00d1c5] p-1 rounded-xl mb-8">
            <div className="bg-[#fdfeff] p-8 rounded-lg">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                <div>
                  <h2 className="section-title mb-6">Plugin VTEX de Izipay</h2>
                  <p className="content-text">
                    Bienvenido a la guía de instalación del plugin VTEX de Izipay. Integra de forma segura y eficiente múltiples métodos de pago en tu tienda online.
                  </p>
                </div>
                <div className="relative">
                  <div className="absolute -inset-1 bg-gradient-to-r from-[#ec3237] to-[#00d1c5] rounded-lg blur opacity-25"></div>
                  <img 
                    src="/lovable-uploads/6908a163-6566-4e04-82b8-5e9d35ad2718.png"
                    alt="Izipay VTEX Integration"
                    className="relative rounded-lg w-full object-cover shadow-xl border border-gray-100"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Segunda sección: Métodos de Pago Aceptados */}
          <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
            <h3 className="subsection-title">Métodos de Pago Aceptados</h3>
            <p className="content-text">
              Acepta múltiples formas de pago y brinda la mejor experiencia a tus clientes:
            </p>
            <div className="payment-methods">
              <div className="payment-method">
                <CreditCard className="payment-method-icon" />
                <span className="payment-method-text">Tarjeta de Crédito</span>
                <span className="text-xs text-gray-500">Visa, Mastercard, American Express</span>
              </div>
              <div className="payment-method">
                <CreditCard className="payment-method-icon" />
                <span className="payment-method-text">Tarjeta de Débito</span>
                <span className="text-xs text-gray-500">Visa Débito, Mastercard Débito</span>
              </div>
              <div className="payment-method">
                <QrCode className="payment-method-icon" />
                <span className="payment-method-text">Código QR</span>
                <span className="text-xs text-gray-500">Pago rápido y seguro</span>
              </div>
              <div className="payment-method">
                <img 
                  src="/lovable-uploads/299fbac6-56c8-4ac1-a545-9cea853ca68c.png"
                  alt="Yape"
                  className="w-12 h-12 mb-2 object-contain"
                />
                <span className="payment-method-text">Yape</span>
                <span className="text-xs text-gray-500">Pago móvil instantáneo</span>
              </div>
            </div>
          </div>

          {/* Tercera sección: Beneficios */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-white p-6 rounded-lg shadow-lg border-t-4 border-[#ec3237]">
              <h4 className="font-semibold text-lg mb-2">Integración Rápida</h4>
              <p className="text-sm text-gray-600">Implementación sencilla y rápida con VTEX IO</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-lg border-t-4 border-[#00d1c5]">
              <h4 className="font-semibold text-lg mb-2">Seguridad Garantizada</h4>
              <p className="text-sm text-gray-600">Transacciones seguras y cifradas</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-lg border-t-4 border-[#ec3237]">
              <h4 className="font-semibold text-lg mb-2">Soporte 24/7</h4>
              <p className="text-sm text-gray-600">Asistencia técnica permanente</p>
            </div>
          </div>

          <div className="mt-8 flex justify-end">
            <button
              onClick={() => setActiveSection("requisitos")}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-[#ec3237] to-[#00d1c5] text-white rounded-lg font-medium hover:opacity-90 transition-all shadow-lg hover:shadow-xl"
            >
              Siguiente: Requisitos
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </section>

        <section id="requisitos" className={activeSection === "requisitos" ? "block" : "hidden"}>
          <h2 className="section-title">Requisitos</h2>
          <h3 className="subsection-title">Requisitos Técnicos</h3>
          <ul className="list-disc pl-6 space-y-2 content-text">
            <li>Cuenta activa en VTEX IO</li>
            <li>CLI de VTEX instalado</li>
            <li>Acceso como administrador a tu tienda VTEX</li>
            <li>Credenciales de Izipay</li>
          </ul>
        </section>

        <section id="integracion" className={activeSection === "integracion" ? "block" : "hidden"}>
          <h2 className="section-title">Integración</h2>
          <p className="content-text">
            Sigue estos pasos para integrar el plugin de Izipay en tu tienda VTEX:
          </p>
          <h3 className="subsection-title">1. Instalación del Plugin</h3>
          <CodeBlock code={sampleCode} />
        </section>

        <section id="flujo-pedidos" className={activeSection === "flujo-pedidos" ? "block" : "hidden"}>
          <h2 className="section-title">Flujo de pedidos</h2>
          <p className="content-text">
            Comprende cómo funciona el proceso de pago desde que el cliente selecciona Izipay hasta la confirmación
            de la transacción.
          </p>
        </section>

        <section id="actualizaciones" className={activeSection === "actualizaciones" ? "block" : "hidden"}>
          <h2 className="section-title">Actualizaciones</h2>
          <p className="content-text">
            Mantente al día con las últimas actualizaciones y mejoras del plugin.
          </p>
        </section>
      </main>
    </div>
  );
};

export default Index;
